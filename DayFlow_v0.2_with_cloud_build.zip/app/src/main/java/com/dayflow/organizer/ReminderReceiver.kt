package com.dayflow.organizer

import android.app.*
import android.content.*
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject

class ReminderReceiver: BroadcastReceiver() {
    override fun onReceive(context:Context,intent:Intent) {
        val id=intent.getLongExtra("task_id",System.currentTimeMillis())
        val title=intent.getStringExtra("task_title") ?: "Task reminder"
        val done=Intent(context,ReminderReceiver::class.java).setAction("DONE").putExtra("task_id",id)
        val snooze=Intent(context,ReminderReceiver::class.java).setAction("SNOOZE").putExtra("task_id",id).putExtra("task_title",title)
        val donePI=PendingIntent.getBroadcast(context,id.toInt()+1,done,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val snoozePI=PendingIntent.getBroadcast(context,id.toInt()+2,snooze,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        if(intent.action=="DONE") {
            val prefs=context.getSharedPreferences("dayflow",0)
            val tasks=JSONArray(prefs.getString("tasks","[]"))
            for(i in 0 until tasks.length()) {
                val item=tasks.optJSONObject(i) ?: continue
                if(item.optLong("id")==id) item.put("done",true)
            }
            prefs.edit().putString("tasks",tasks.toString()).apply()
            context.getSystemService(NotificationManager::class.java).cancel(id.toInt())
            return
        }
        if(intent.action=="SNOOZE") {
            val next=Intent(context,ReminderReceiver::class.java).putExtra("task_id",id).putExtra("task_title",title)
            val pi=PendingIntent.getBroadcast(context,id.toInt(),next,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            context.getSystemService(AlarmManager::class.java).setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,System.currentTimeMillis()+10*60_000,pi)
            context.getSystemService(NotificationManager::class.java).cancel(id.toInt())
            return
        }
        val n=Notification.Builder(context,"dayflow_reminders")
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title)
            .setContentText("Your task is scheduled for now.")
            .setAutoCancel(true)
            .addAction(android.R.drawable.checkbox_on_background,"Done",donePI)
            .addAction(android.R.drawable.ic_lock_idle_alarm,"Snooze 10 min",snoozePI)
            .setPriority(Notification.PRIORITY_HIGH)
            .build()
        context.getSystemService(NotificationManager::class.java).notify(id.toInt(),n)
    }
}
