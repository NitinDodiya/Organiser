package com.dayflow.organizer

import android.app.*
import android.content.*
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.util.*

data class Task(val id: Long, val title: String, val category: String, val due: String, val done: Boolean = false, val dueAtMillis: Long = 0L)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 100)
        }
        setContent { DayFlowApp(this) }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("dayflow_reminders", "Task reminders", NotificationManager.IMPORTANCE_HIGH)
            channel.description = "Friendly reminders for your tasks"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}

@Composable
fun DayFlowApp(context: Context) {
    val prefs = context.getSharedPreferences("dayflow", Context.MODE_PRIVATE)
    var tasks by remember { mutableStateOf(loadTasks(prefs)) }
    var accent by remember { mutableIntStateOf(prefs.getInt("accent", 0xFF5B67F1.toInt())) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", false)) }
    var tab by remember { mutableStateOf("Today") }
    var showAdd by remember { mutableStateOf(false) }
    var showCustomize by remember { mutableStateOf(false) }

    val accentColor = Color(accent)
    val bg = if (dark) Color(0xFF111318) else Color(0xFFF5F6FA)
    val surface = if (dark) Color(0xFF1C1F27) else Color.White
    val fg = if (dark) Color(0xFFF5F5F7) else Color(0xFF222431)

    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary=accentColor, background=bg, surface=surface)
        else lightColorScheme(primary=accentColor, background=bg, surface=surface)) {
        Scaffold(containerColor=bg, bottomBar = {
            NavigationBar(containerColor=surface) {
                listOf("Today","Calendar","Habits","Notes","Lists").forEach { label ->
                    NavigationBarItem(selected=tab==label, onClick={tab=label},
                        icon={ Icon(when(label) {
                            "Today" -> Icons.Default.CheckCircle
                            "Calendar" -> Icons.Default.CalendarMonth
                            "Habits" -> Icons.Default.Repeat
                            "Notes" -> Icons.Default.EditNote
                            else -> Icons.Default.List
                        }, contentDescription=label) }, label={Text(label)})
                }
            }
        }, floatingActionButton = {
            FloatingActionButton(onClick={showAdd=true}, containerColor=accentColor, contentColor=Color.White) {
                Icon(Icons.Default.Add, "Add task")
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal=18.dp)) {
                Row(Modifier.fillMaxWidth().padding(top=20.dp), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
                    Column {
                        Text("DAYFLOW", fontSize=12.sp, fontWeight=FontWeight.Bold, color=accentColor, letterSpacing=2.sp)
                        Text(when(tab) { "Today"->"Today"; "Calendar"->"Your calendar"; "Habits"->"Habits"; "Notes"->"Notes"; else->"Your lists" },
                            fontSize=28.sp, fontWeight=FontWeight.Bold, color=fg)
                    }
                    IconButton(onClick={showCustomize=true}) { Icon(Icons.Default.Palette, "Customize", tint=fg) }
                }
                if (tab=="Calendar") {
                    CalendarSection(tasks, surface, fg, accentColor, onToggle={ id ->
                        tasks=tasks.map { if(it.id==id) it.copy(done=!it.done) else it }
                        saveTasks(prefs,tasks)
                    }, onReminder={ task -> scheduleReminder(context,task) })
                } else if (tab=="Today") {
                    Card(Modifier.fillMaxWidth().padding(top=16.dp), colors=CardDefaults.cardColors(containerColor=accentColor), shape=RoundedCornerShape(22.dp)) {
                        Column(Modifier.padding(18.dp)) {
                            Text("YOUR DAY, AT A GLANCE", color=Color.White.copy(.8f), fontSize=11.sp, fontWeight=FontWeight.Bold)
                            Text("${tasks.count{!it.done}} tasks left", color=Color.White, fontSize=24.sp, fontWeight=FontWeight.Bold)
                            Text("Small steps make great days.", color=Color.White.copy(.9f))
                        }
                    }
                    Row(Modifier.padding(top=20.dp, bottom=8.dp), verticalAlignment=Alignment.CenterVertically) {
                        Text("My tasks", fontWeight=FontWeight.Bold, fontSize=18.sp, color=fg)
                        Spacer(Modifier.weight(1f))
                        Text("${tasks.count{it.done}} completed", color=accentColor, fontSize=13.sp)
                    }
                    LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)) {
                        items(tasks, key={it.id}) { task ->
                            TaskCard(task, surface, fg, accentColor, onToggle={
                                tasks=tasks.map { if(it.id==task.id) it.copy(done=!it.done) else it }
                                saveTasks(prefs,tasks)
                            }, onReminder={scheduleReminder(context,task)})
                        }
                    }
                } else {
                    EmptyFeature(tab, surface, fg, accentColor)
                }
            }
        }
        if(showAdd) AddTaskDialog(onDismiss={showAdd=false}, onSave={title,cat,due,dueAt,reminder ->
            val t=Task(System.currentTimeMillis(),title,cat,due,dueAtMillis=dueAt)
            tasks=tasks + t
            saveTasks(prefs,tasks)
            if(reminder) scheduleReminder(context,t)
            showAdd=false
        })
        if(showCustomize) CustomizeDialog(accent,dark,onAccent={accent=it;prefs.edit().putInt("accent",it).apply()},onDark={dark=it;prefs.edit().putBoolean("dark",it).apply()},onDismiss={showCustomize=false})
    }
}

@Composable
fun TaskCard(task: Task, surface: Color, fg: Color, accent: Color, onToggle:()->Unit, onReminder:()->Unit) {
    Card(colors=CardDefaults.cardColors(containerColor=surface), shape=RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment=Alignment.CenterVertically) {
            Checkbox(checked=task.done,onCheckedChange={onToggle()}, colors=CheckboxDefaults.colors(checkedColor=accent))
            Column(Modifier.weight(1f).padding(start=5.dp)) {
                Text(task.title, color=fg, fontWeight=FontWeight.SemiBold)
                Text("${task.category}  •  ${task.due}", color=fg.copy(.55f), fontSize=12.sp)
            }
            IconButton(onClick=onReminder) { Icon(Icons.Default.NotificationsActive, "Set reminder", tint=accent) }
        }
    }
}

@Composable
fun AddTaskDialog(onDismiss:()->Unit,onSave:(String,String,String,Long,Boolean)->Unit) {
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Personal") }
    var selectedMillis by remember { mutableLongStateOf(System.currentTimeMillis()+60*60*1000) }
    var reminder by remember { mutableStateOf(true) }
    val pickerContext = androidx.compose.ui.platform.LocalContext.current
    val dateText = remember(selectedMillis) { java.text.SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(Date(selectedMillis)) }
    val timeText = remember(selectedMillis) { java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(selectedMillis)) }
    AlertDialog(onDismissRequest=onDismiss, title={Text("New task")}, text={
        Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(title,onValueChange={title=it},label={Text("Task name")},singleLine=true)
            OutlinedTextField(category,onValueChange={category=it},label={Text("Category")},singleLine=true)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                OutlinedButton(modifier=Modifier.weight(1f),onClick={
                    val c=Calendar.getInstance().apply { timeInMillis=selectedMillis }
                    DatePickerDialog(pickerContext, { _, y, m, d ->
                        c.set(Calendar.YEAR,y); c.set(Calendar.MONTH,m); c.set(Calendar.DAY_OF_MONTH,d)
                        selectedMillis=c.timeInMillis
                    },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show()
                }) { Icon(Icons.Default.CalendarMonth, null); Spacer(Modifier.width(4.dp)); Text(dateText) }
                OutlinedButton(modifier=Modifier.weight(1f),onClick={
                    val c=Calendar.getInstance().apply { timeInMillis=selectedMillis }
                    TimePickerDialog(pickerContext, { _, h, min ->
                        c.set(Calendar.HOUR_OF_DAY,h); c.set(Calendar.MINUTE,min); c.set(Calendar.SECOND,0)
                        selectedMillis=c.timeInMillis
                    },c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),false).show()
                }) { Icon(Icons.Default.Schedule, null); Spacer(Modifier.width(4.dp)); Text(timeText) }
            }
            Row(verticalAlignment=Alignment.CenterVertically) { Checkbox(reminder,{reminder=it}); Text("Add reminder") }
            Text("Reminder will be scheduled for the selected date and time.",style=MaterialTheme.typography.bodySmall)
        }
    }, confirmButton={TextButton(onClick={if(title.isNotBlank())onSave(title,category,"$dateText • $timeText",selectedMillis,reminder)}){Text("Save task")}}, dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}

@Composable
fun CalendarSection(tasks:List<Task>,surface:Color,fg:Color,accent:Color,onToggle:(Long)->Unit,onReminder:(Task)->Unit) {
    var monthOffset by remember { mutableIntStateOf(0) }
    var selectedDay by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val month=Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH,1); add(Calendar.MONTH,monthOffset) }
    val year=month.get(Calendar.YEAR); val monthIndex=month.get(Calendar.MONTH)
    val monthLabel=java.text.SimpleDateFormat("MMMM yyyy",Locale.getDefault()).format(month.time)
    val days=month.getActualMaximum(Calendar.DAY_OF_MONTH)
    val firstWeekday=(month.get(Calendar.DAY_OF_WEEK)-Calendar.SUNDAY)
    val selected=Calendar.getInstance().apply { timeInMillis=selectedDay }
    val selectedTasks=tasks.filter { task -> task.dueAtMillis>0 && Calendar.getInstance().apply{timeInMillis=task.dueAtMillis}.let{it.get(Calendar.YEAR)==selected.get(Calendar.YEAR)&&it.get(Calendar.DAY_OF_YEAR)==selected.get(Calendar.DAY_OF_YEAR)} }
    Card(Modifier.fillMaxWidth().padding(top=14.dp),colors=CardDefaults.cardColors(containerColor=surface),shape=RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                IconButton(onClick={monthOffset--}) { Icon(Icons.Default.ChevronLeft,"Previous month") }
                Text(monthLabel,modifier=Modifier.weight(1f),fontWeight=FontWeight.Bold,fontSize=18.sp,color=fg)
                IconButton(onClick={monthOffset++}) { Icon(Icons.Default.ChevronRight,"Next month") }
            }
            Row(Modifier.fillMaxWidth()) { listOf("S","M","T","W","T","F","S").forEach { Text(it,Modifier.weight(1f),textAlign=androidx.compose.ui.text.style.TextAlign.Center,color=fg.copy(.55f),fontSize=12.sp) } }
            val cells=firstWeekday+days
            for (row in 0 until (cells+6)/7) {
                Row(Modifier.fillMaxWidth()) {
                    for(col in 0..6) {
                        val day=(row*7+col-firstWeekday+1)
                        Box(Modifier.weight(1f).aspectRatio(1f),contentAlignment=Alignment.Center) {
                            if(day in 1..days) {
                                val dayCal=Calendar.getInstance().apply { set(year,monthIndex,day,0,0,0); set(Calendar.MILLISECOND,0) }
                                val isSelected=selected.get(Calendar.YEAR)==year&&selected.get(Calendar.MONTH)==monthIndex&&selected.get(Calendar.DAY_OF_MONTH)==day
                                val hasTasks=tasks.any { it.dueAtMillis>0 && Calendar.getInstance().apply{timeInMillis=it.dueAtMillis}.let{d->d.get(Calendar.YEAR)==year&&d.get(Calendar.MONTH)==monthIndex&&d.get(Calendar.DAY_OF_MONTH)==day} }
                                Box(Modifier.size(34.dp).background(if(isSelected)accent else Color.Transparent,CircleShape).clickable{selectedDay=dayCal.timeInMillis},contentAlignment=Alignment.Center) {
                                    Column(horizontalAlignment=Alignment.CenterVertically) {
                                        Text("$day",color=if(isSelected)Color.White else fg,fontSize=13.sp)
                                        if(hasTasks) Box(Modifier.size(4.dp).background(if(isSelected)Color.White else accent,CircleShape))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    Text(java.text.SimpleDateFormat("EEEE, MMM d",Locale.getDefault()).format(Date(selectedDay)),modifier=Modifier.padding(top=18.dp,bottom=8.dp),fontWeight=FontWeight.Bold,fontSize=17.sp,color=fg)
    if(selectedTasks.isEmpty()) {
        Card(colors=CardDefaults.cardColors(containerColor=surface),shape=RoundedCornerShape(16.dp)) { Text("No scheduled tasks for this day.",Modifier.padding(16.dp),color=fg.copy(.65f)) }
    } else {
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.heightIn(max=360.dp)) {
            items(selectedTasks,key={it.id}) { task -> TaskCard(task,surface,fg,accent,{onToggle(task.id)},{onReminder(task)}) }
        }
    }
}

@Composable
fun CustomizeDialog(accent:Int,dark:Boolean,onAccent:(Int)->Unit,onDark:(Boolean)->Unit,onDismiss:()->Unit) {
    val colors=listOf(0xFF5B67F1,0xFF12A889,0xFFFF8A4C,0xFFE4547B,0xFF8B5CF6,0xFF2196D2,0xFF424B5A).map{it.toInt()}
    AlertDialog(onDismissRequest=onDismiss,title={Text("Customization studio")},text={
        Column(verticalArrangement=Arrangement.spacedBy(14.dp)) {
            Text("Accent color")
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { colors.forEach { c ->
                Box(Modifier.size(32.dp).background(Color(c),CircleShape).clickable{onAccent(c)}, contentAlignment=Alignment.Center) {
                    if(accent==c) Icon(Icons.Default.Check,"Selected",tint=Color.White)
                }
            } }
            Row(verticalAlignment=Alignment.CenterVertically) { Text("Dark mode"); Spacer(Modifier.weight(1f)); Switch(dark,onDark) }
            Text("More options planned: wallpapers, fonts, card styles, compact mode and custom colors.", fontSize=13.sp)
        }
    },confirmButton={TextButton(onClick=onDismiss){Text("Done")}})
}

@Composable
fun EmptyFeature(tab:String,surface:Color,fg:Color,accent:Color) {
    Card(Modifier.fillMaxWidth().padding(top=22.dp),colors=CardDefaults.cardColors(containerColor=surface),shape=RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally) {
            Icon(Icons.Default.AutoAwesome,contentDescription=null,tint=accent,modifier=Modifier.size(36.dp))
            Text("$tab module",fontWeight=FontWeight.Bold,color=fg,fontSize=18.sp)
            Text("This section is part of the planned organizer experience. The first build focuses on tasks and reminders.",color=fg.copy(.65f))
        }
    }
}

fun loadTasks(prefs: android.content.SharedPreferences): List<Task> {
    val arr=JSONArray(prefs.getString("tasks","[]"))
    return (0 until arr.length()).map { i ->
        val o=arr.getJSONObject(i)
        Task(o.getLong("id"),o.getString("title"),o.getString("category"),o.getString("due"),o.optBoolean("done"),o.optLong("dueAtMillis",0L))
    }
}
fun saveTasks(prefs: android.content.SharedPreferences,tasks:List<Task>) {
    val arr=JSONArray()
    tasks.forEach { arr.put(JSONObject().put("id",it.id).put("title",it.title).put("category",it.category).put("due",it.due).put("done",it.done).put("dueAtMillis",it.dueAtMillis)) }
    prefs.edit().putString("tasks",arr.toString()).apply()
}

fun scheduleReminder(context:Context,task:Task) {
    val intent=Intent(context,ReminderReceiver::class.java).putExtra("task_id",task.id).putExtra("task_title",task.title)
    val pending=PendingIntent.getBroadcast(context,task.id.toInt(),intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val alarm=context.getSystemService(AlarmManager::class.java)
    val fireAt=if(task.dueAtMillis>System.currentTimeMillis()) task.dueAtMillis else System.currentTimeMillis()+60_000
    alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,fireAt,pending)
}
