# DayFlow — Android organizer starter

First prototype project: task list, task categories, persistent local task data,
theme/accent controls, and notification actions (Done / Snooze 10 min).

## Build requirements
- Android Studio (recommended)
- JDK 17+
- Android SDK Platform 35
- Gradle 8.9+ compatible with Android Gradle Plugin 8.7.3

Open this folder in Android Studio, allow Gradle sync, then:
Build > Build Bundle(s) / APK(s) > Build APK(s).

## Notes
This is a starter implementation, not a finished release. Reminders currently use
a one-minute test delay when scheduled. Notification permissions and exact-alarm
permission behavior vary by Android version and should be tested on device.
Calendar, habits, notes, lists, richer reminder scheduling, widgets, backup,
and broader personalization are planned for subsequent iterations.

## Development update — 2026-11-18
- Added task date/time selection using Android date and time dialogs.
- Tasks now persist a scheduled timestamp alongside the human-readable due label.
- Calendar tab now renders a month grid, navigation between months, task markers, and selected-day task list.
- Reminder alarm uses the selected scheduled timestamp when it is in the future (otherwise falls back to a 1-minute test reminder).
- Build remains unverified: this environment does not currently have Android SDK/Gradle installed.
- Notification Done action now updates the persisted task completion flag and dismisses the notification; Snooze schedules another reminder in 10 minutes and dismisses the current notification.


## Build APK using GitHub Actions (cloud build)
1. Create a GitHub repository and upload the contents of this project.
2. Open the repository's **Actions** tab and select **Build DayFlow APK**.
3. Choose **Run workflow** (or push to the `main` branch).
4. When the build completes, open the run and download the **DayFlow-debug-apk** artifact.
5. Extract the artifact to get `app-debug.apk`, then install it on your Android device.

This workflow is a convenience for building in GitHub's hosted runner; the APK is not precompiled here.
